﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoEkzamen
{
    internal class Method4
    {
       
        public int CalculateRequiredMaterial(int productTypeId, int materialTypeId, int productCount,double productParam1, double productParam2,
            double productCoefficient, double defectPercentage)
        {
            if (productTypeId <= 0 || materialTypeId <= 0 || productCount <= 0 ||
                productParam1 <= 0 || productParam2 <= 0 ||
                productCoefficient <= 0 || defectPercentage < 0)
            {
                return -1;
            }

            try
            {
                // Расчет количества материала на одну единицу продукции
                double materialPerUnit = productParam1 * productParam2 * productCoefficient;

                // Увеличение на процент брака
                double defectMultiplier = 1 + (defectPercentage / 100);

                // Итоговое количество материала
                double totalMaterial = productCount * materialPerUnit * defectMultiplier;

                // Округление до целого числа и возврат
                return (int)Math.Ceiling(totalMaterial);
            }
            catch
            {
                return -1;
            }
        }




    }
}
