﻿using DemoEkzamen.Model;
using System;
using System.Windows;
using System.Windows.Controls;

namespace DemoEkzamen
{
    /// <summary>
    /// Логика взаимодействия для EditPartner.xaml
    /// </summary>
    public partial class EditPartner : Page
    {
        private Partner _currentPartner;

        public EditPartner(Partner partner)
        {
            InitializeComponent();
            _currentPartner = partner;

            TypePartnerComboBox.SelectedItem = _currentPartner.TypePartner;
            NamePartnerInput.Text = _currentPartner.NameParnter;
            DirectorNameInput.Text = _currentPartner.DirectorParnterName;
            DirectorSurnameInput.Text = _currentPartner.DirectorParnterSurname;
            DirectorPatronymicInput.Text = _currentPartner.DirectorParnterPatronymic;
            EmailPartnerInput.Text = _currentPartner.EmailParnter;
            PhonePartnerInput.Text = _currentPartner.PhoneParnter;
            AddressIndexInput.Text = _currentPartner.AddressIndex;
            AddressRegionInput.Text = _currentPartner.AddressRegion;
            AddressCityInput.Text = _currentPartner.AddressCity;
            AddressStreetInput.Text = _currentPartner.AddressStreet;
            AddressNumberhouseInput.Text = _currentPartner.AddressNumberhouse;
            InnPartnerInput.Text = _currentPartner.InnParnter;
            RatingPartnerInput.Text = _currentPartner.RatingParnter;
        }

        private void SaveEdutParnnterBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(NamePartnerInput.Text))
                {
                    MessageBox.Show("Поле 'Название партнера' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(DirectorNameInput.Text))
                {
                    MessageBox.Show("Поле 'Имя директора' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(DirectorSurnameInput.Text))
                {
                    MessageBox.Show("Поле 'Фамилия директора' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(EmailPartnerInput.Text))
                {
                    MessageBox.Show("Поле 'Email' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(PhonePartnerInput.Text))
                {
                    MessageBox.Show("Поле 'Телефон' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressIndexInput.Text))
                {
                    MessageBox.Show("Поле 'Индекс адреса' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressRegionInput.Text))
                {
                    MessageBox.Show("Поле 'Регион' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressCityInput.Text))
                {
                    MessageBox.Show("Поле 'Город' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressStreetInput.Text))
                {
                    MessageBox.Show("Поле 'Улица' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressNumberhouseInput.Text))
                {
                    MessageBox.Show("Поле 'Номер дома' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(InnPartnerInput.Text))
                {
                    MessageBox.Show("Поле 'ИНН партнера' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!decimal.TryParse(RatingPartnerInput.Text, out decimal rating) || rating <= 0)
                {
                    MessageBox.Show("Поле 'Рейтинг партнера' должно быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }


                string cleanedPhone = PhonePartnerInput.Text.Replace(" ", "");

                if (!long.TryParse(cleanedPhone, out long phone))
                {
                    MessageBox.Show("Поле 'Телефон' должно содержать только цифры.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }


                if (!long.TryParse(InnPartnerInput.Text, out long inn))
                {
                    MessageBox.Show("Поле 'ИНН партнера' должно содержать только цифры.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!decimal.TryParse(RatingPartnerInput.Text, out decimal ratingg))
                {
                    MessageBox.Show("Поле 'Рейтинг партнера' должно быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                if (!decimal.TryParse(AddressNumberhouseInput.Text, out decimal addressNumberhouseInput))
                {
                    MessageBox.Show("Поле 'Номер дома' должно быть числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                _currentPartner.TypePartner = (TypePartnerComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                _currentPartner.NameParnter = NamePartnerInput.Text;
                _currentPartner.DirectorParnterName = DirectorNameInput.Text;
                _currentPartner.DirectorParnterSurname = DirectorSurnameInput.Text;
                _currentPartner.DirectorParnterPatronymic = DirectorPatronymicInput.Text;
                _currentPartner.EmailParnter = EmailPartnerInput.Text;
                _currentPartner.PhoneParnter = PhonePartnerInput.Text;
                _currentPartner.AddressIndex = AddressIndexInput.Text;
                _currentPartner.AddressRegion = AddressRegionInput.Text;
                _currentPartner.AddressCity = AddressCityInput.Text;
                _currentPartner.AddressStreet = AddressStreetInput.Text;
                _currentPartner.AddressNumberhouse = AddressNumberhouseInput.Text;
                _currentPartner.InnParnter = InnPartnerInput.Text;
                _currentPartner.RatingParnter = RatingPartnerInput.Text;

                using (var context = new DbPartnersContext())
                {
                    context.Partners.Update(_currentPartner);
                    context.SaveChanges();
                }

                MessageBox.Show("Данные партнера успешно обновлены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                NavigationService.Navigate(new MainPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных партнера: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BacEditBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }
    }
}