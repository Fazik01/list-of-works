﻿using DemoEkzamen.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DemoEkzamen
{
    public partial class ProductHistoryPage : Page
    {
        private List<Partner> _partners;
        private List<PartnerProduct> _partnerProducts;

        public ProductHistoryPage()
        {
            InitializeComponent();
            LoadPartners();
        }

        private void LoadPartners()
        {
            try
            {
                using (var context = new DbPartnersContext())
                {
                    _partners = context.Partners.ToList();
                    PartnerComboBox.ItemsSource = _partners;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке партнеров: {ex.Message}");
            }
        }

        private void PartnerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PartnerComboBox.SelectedValue is int partnerId)
            {
                LoadPartnerProducts(partnerId);
            }
        }

        private void LoadPartnerProducts(int partnerId)
        {
            try
            {
                using (var context = new DbPartnersContext())
                {
                    // Загружаем PartnerProducts вместе с данными о продукте
                    _partnerProducts = context.PartnerProducts
                        .Include(pp => pp.ArtikulProductNavigation)
                        .Where(pp => pp.IdPartner == partnerId)
                        .ToList();

                    HistoryListView.ItemsSource = _partnerProducts;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке истории реализации: {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}