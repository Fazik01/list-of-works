﻿using DemoEkzamen.Model;
using System;
using System.Windows;
using System.Windows.Controls;

namespace DemoEkzamen
{
    /// <summary>
    /// Логика взаимодействия для AddParnterPage.xaml
    /// </summary>
    public partial class AddParnterPage : Page
    {
        public AddParnterPage()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверка на пустые поля
                if (string.IsNullOrWhiteSpace(NamePartnerInput.Text))
                {
                    MessageBox.Show("Поле 'Название партнера' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(DirectorNameInput.Text))
                {
                    MessageBox.Show("Поле 'Имя директора' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(DirectorSurnameInput.Text))
                {
                    MessageBox.Show("Поле 'Фамилия директора' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(EmailPartnerInput.Text))
                {
                    MessageBox.Show("Поле 'Email' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(PhonePartnerInput.Text))
                {
                    MessageBox.Show("Поле 'Телефон' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressIndexInput.Text))
                {
                    MessageBox.Show("Поле 'Индекс адреса' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressRegionInput.Text))
                {
                    MessageBox.Show("Поле 'Регион' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressCityInput.Text))
                {
                    MessageBox.Show("Поле 'Город' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressStreetInput.Text))
                {
                    MessageBox.Show("Поле 'Улица' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(AddressNumberhouseInput.Text))
                {
                    MessageBox.Show("Поле 'Номер дома' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(InnPartnerInput.Text))
                {
                    MessageBox.Show("Поле 'ИНН партнера' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(RatingPartnerInput.Text))
                {
                    MessageBox.Show("Поле 'Рейтинг партнера' не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!long.TryParse(PhonePartnerInput.Text, out long phone))
                {
                    MessageBox.Show("Поле 'Телефон' должно содержать только цифры.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!long.TryParse(InnPartnerInput.Text, out long inn))
                {
                    MessageBox.Show("Поле 'ИНН партнера' должно содержать только цифры.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (!decimal.TryParse(RatingPartnerInput.Text, out decimal rating) || rating <= 0)
                {
                    MessageBox.Show("Поле 'Рейтинг партнера' должно быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var selectedTypePartner = (TypePartnerComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                if (string.IsNullOrEmpty(selectedTypePartner))
                {
                    MessageBox.Show("Выберите тип партнера.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var newPartner = new Partner
                {
                    TypePartner = selectedTypePartner,
                    NameParnter = NamePartnerInput.Text,
                    DirectorParnterName = DirectorNameInput.Text,
                    DirectorParnterSurname = DirectorSurnameInput.Text,
                    DirectorParnterPatronymic = DirectorPatronymicInput.Text,
                    EmailParnter = EmailPartnerInput.Text,
                    PhoneParnter = PhonePartnerInput.Text,
                    AddressIndex = AddressIndexInput.Text,
                    AddressRegion = AddressRegionInput.Text,
                    AddressCity = AddressCityInput.Text,
                    AddressStreet = AddressStreetInput.Text,
                    AddressNumberhouse = AddressNumberhouseInput.Text,
                    InnParnter = InnPartnerInput.Text,
                    RatingParnter = RatingPartnerInput.Text
                };

                using (var db = new DbPartnersContext())
                {
                    db.Partners.Add(newPartner);
                    db.SaveChanges();
                }

                MessageBox.Show("Партнер успешно добавлен!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Information);

                NavigationService.Navigate(new MainPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении партнера: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}