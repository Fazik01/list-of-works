﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DemoEkzamen.Model;

public partial class DbPartnersContext : DbContext
{
    public DbPartnersContext()
    {
    }

    public DbPartnersContext(DbContextOptions<DbPartnersContext> options)
        : base(options)
    {
    }

    public virtual DbSet<MarerialType> MarerialTypes { get; set; }

    public virtual DbSet<Partner> Partners { get; set; }

    public virtual DbSet<PartnerProduct> PartnerProducts { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductType> ProductTypes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;user=root;password=Faza2005;database=db_partners", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.35-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<MarerialType>(entity =>
        {
            entity.HasKey(e => e.IdMarerialType).HasName("PRIMARY");

            entity.ToTable("marerial_type");

            entity.Property(e => e.IdMarerialType).HasColumnName("id_marerial_type");
            entity.Property(e => e.DefectMarerialType)
                .HasColumnType("double(5,2)")
                .HasColumnName("defect_marerial_type");
            entity.Property(e => e.NameMarerial)
                .HasMaxLength(45)
                .HasColumnName("name_marerial");
        });

        modelBuilder.Entity<Partner>(entity =>
        {
            entity.HasKey(e => e.IdPartner).HasName("PRIMARY");

            entity.ToTable("partners");

            entity.Property(e => e.IdPartner).HasColumnName("id_partner");
            entity.Property(e => e.AddressCity)
                .HasMaxLength(45)
                .HasColumnName("address_city");
            entity.Property(e => e.AddressIndex)
                .HasMaxLength(50)
                .HasColumnName("address_index");
            entity.Property(e => e.AddressNumberhouse)
                .HasMaxLength(45)
                .HasColumnName("address_numberhouse");
            entity.Property(e => e.AddressRegion)
                .HasMaxLength(45)
                .HasColumnName("address_region");
            entity.Property(e => e.AddressStreet)
                .HasMaxLength(45)
                .HasColumnName("address_street");
            entity.Property(e => e.DirectorParnterName)
                .HasMaxLength(50)
                .HasColumnName("director_parnter_name");
            entity.Property(e => e.DirectorParnterPatronymic)
                .HasMaxLength(45)
                .HasColumnName("director_parnter_patronymic");
            entity.Property(e => e.DirectorParnterSurname)
                .HasMaxLength(45)
                .HasColumnName("director_parnter_surname");
            entity.Property(e => e.EmailParnter)
                .HasMaxLength(50)
                .HasColumnName("email_parnter");
            entity.Property(e => e.InnParnter)
                .HasMaxLength(50)
                .HasColumnName("inn_parnter");
            entity.Property(e => e.NameParnter)
                .HasMaxLength(50)
                .HasColumnName("name_parnter");
            entity.Property(e => e.PhoneParnter)
                .HasMaxLength(50)
                .HasColumnName("phone_parnter");
            entity.Property(e => e.RatingParnter)
                .HasMaxLength(50)
                .HasColumnName("rating_parnter");
            entity.Property(e => e.TypePartner)
                .HasMaxLength(5)
                .HasColumnName("type_partner");
        });

        modelBuilder.Entity<PartnerProduct>(entity =>
        {
            entity.HasKey(e => e.IdParnerProduct).HasName("PRIMARY");

            entity.ToTable("partner_products");

            entity.HasIndex(e => e.IdPartner, "fk_partner");

            entity.HasIndex(e => e.ArtikulProduct, "fk_product");

            entity.Property(e => e.IdParnerProduct).HasColumnName("id_parner_product");
            entity.Property(e => e.ArtikulProduct)
                .HasMaxLength(7)
                .HasColumnName("artikul_product");
            entity.Property(e => e.CountProduct).HasColumnName("count_product");
            entity.Property(e => e.DataSales).HasColumnName("data_sales");
            entity.Property(e => e.IdPartner).HasColumnName("id_partner");

            entity.HasOne(d => d.ArtikulProductNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.ArtikulProduct)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_product");

            entity.HasOne(d => d.IdPartnerNavigation).WithMany(p => p.PartnerProducts)
                .HasForeignKey(d => d.IdPartner)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_partner");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.ArtikulProduct).HasName("PRIMARY");

            entity.ToTable("products");

            entity.HasIndex(e => e.IdProductType, "fk_product_type");

            entity.Property(e => e.ArtikulProduct)
                .HasMaxLength(7)
                .HasColumnName("artikul_product");
            entity.Property(e => e.IdProductType).HasColumnName("id_product_type");
            entity.Property(e => e.MinPrice)
                .HasColumnType("double(10,4)")
                .HasColumnName("min_price");
            entity.Property(e => e.NameProduct)
                .HasMaxLength(500)
                .HasColumnName("name_product");

            entity.HasOne(d => d.IdProductTypeNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.IdProductType)
                .HasConstraintName("fk_product_type");
        });

        modelBuilder.Entity<ProductType>(entity =>
        {
            entity.HasKey(e => e.IdProductType).HasName("PRIMARY");

            entity.ToTable("product_type");

            entity.Property(e => e.IdProductType).HasColumnName("id_product_type");
            entity.Property(e => e.KoefProductType)
                .HasColumnType("double(5,2)")
                .HasColumnName("koef_product_type");
            entity.Property(e => e.NameProduct)
                .HasMaxLength(45)
                .HasColumnName("name_product");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
