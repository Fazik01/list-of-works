﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DemoEkzamen.Model;

public partial class Partner
{
    public int IdPartner { get; set; }

    public string TypePartner { get; set; } = null!;

    public string NameParnter { get; set; } = null!;

    public string DirectorParnterName { get; set; } = null!;

    public string DirectorParnterSurname { get; set; } = null!;

    public string DirectorParnterPatronymic { get; set; } = null!;

    public string EmailParnter { get; set; } = null!;

    public string PhoneParnter { get; set; } = null!;

    public string AddressIndex { get; set; } = null!;

    public string AddressRegion { get; set; } = null!;

    public string AddressCity { get; set; } = null!;

    public string AddressStreet { get; set; } = null!;

    public string AddressNumberhouse { get; set; } = null!;

    public string InnParnter { get; set; } = null!;

    public string RatingParnter { get; set; } = null!;
    public string DirectorFullName => $"{DirectorParnterSurname} {DirectorParnterName} {DirectorParnterPatronymic}";


    public virtual ICollection<PartnerProduct> PartnerProducts { get; } = new List<PartnerProduct>();

    public string Discount
    {
        get
        {
            int totalSoldProducts = PartnerProducts.Sum(pp => pp.CountProduct);

            if (totalSoldProducts <= 10000)
            {
                return "0%";
            }
            else if (totalSoldProducts <= 50000)
            {
                return "5%";
            }
            else if (totalSoldProducts <= 300000)
            {
                return "10%";
            }
            else
            {
                return "15%";
            }
        }
    }



}
