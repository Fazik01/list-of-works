﻿using System;
using System.Collections.Generic;

namespace DemoEkzamen.Model;

public partial class Product
{
    public string ArtikulProduct { get; set; } = null!;

    public int? IdProductType { get; set; }

    public string NameProduct { get; set; } = null!;

    public double MinPrice { get; set; }

    public virtual ProductType? IdProductTypeNavigation { get; set; }

    public virtual ICollection<PartnerProduct> PartnerProducts { get; } = new List<PartnerProduct>();
}
