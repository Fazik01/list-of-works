﻿using DemoEkzamen.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DemoEkzamen
{
    public partial class MainPage : Page
    {
        public ObservableCollection<Partner> Partners { get; set; }

        public MainPage()
        {
            InitializeComponent();
            LoadPartners();
        }

        private void LoadPartners()
        {
            using (var context = new DbPartnersContext())
            {
                var partnersList = context.Partners.Include(p => p.PartnerProducts).ToList();
                Partners = new ObservableCollection<Partner>(partnersList);
            }

            DataContext = this;
        }

        private void AddparntersBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddParnterPage());
        }

        private void ListView_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var selectedPartner = (sender as ListView).SelectedItem as Partner;

            if (selectedPartner != null)
            {
                NavigationService.Navigate(new EditPartner(selectedPartner));
            }
        }

        private void HistoryBtn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProductHistoryPage());

        }
    }
}