﻿using System;
using System.Collections.Generic;

namespace DemoEkzamen.Model;

public partial class ProductType
{
    public int IdProductType { get; set; }

    public double KoefProductType { get; set; }

    public string NameProduct { get; set; } = null!;

    public virtual ICollection<Product> Products { get; } = new List<Product>();
}
