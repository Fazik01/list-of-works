﻿using System;
using System.Collections.Generic;

namespace DemoEkzamen.Model;

public partial class PartnerProduct
{
    public int IdParnerProduct { get; set; }

    public string ArtikulProduct { get; set; } = null!;

    public int IdPartner { get; set; }

    public int CountProduct { get; set; }

    public DateOnly DataSales { get; set; }

    public virtual Product ArtikulProductNavigation { get; set; } = null!;

    public virtual Partner IdPartnerNavigation { get; set; } = null!;
}
