﻿using System;
using System.Collections.Generic;

namespace DemoEkzamen.Model;

public partial class MarerialType
{
    public int IdMarerialType { get; set; }

    public double DefectMarerialType { get; set; }

    public string NameMarerial { get; set; } = null!;
}
